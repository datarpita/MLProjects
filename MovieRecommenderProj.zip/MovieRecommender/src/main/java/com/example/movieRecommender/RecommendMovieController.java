package com.example.movieRecommender;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class RecommendMovieController {
	
	@RequestMapping(name="/recommend", method=RequestMethod.POST)
	public void recommend(HttpServletRequest request, HttpServletResponse response){
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
			String json = "";
			if(br != null){
			    json = br.readLine();
			}
			System.out.println("Json=="+json);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

}
