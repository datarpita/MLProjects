package com.azureml.studentperf.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentPerfPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentPerfPortalApplication.class, args);
	}
}
