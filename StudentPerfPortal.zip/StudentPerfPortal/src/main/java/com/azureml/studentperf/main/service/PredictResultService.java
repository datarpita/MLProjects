package com.azureml.studentperf.main.service;

import java.util.ArrayList;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.azureml.studentperf.pojo.multiple.InputMultipleJson;
import com.azureml.studentperf.pojo.multiple.OutputMultipleJson;
import com.azureml.studentperf.pojo.single.InputJson;
import com.azureml.studentperf.pojo.single.OutputJson;
import com.google.gson.Gson;

@Service
public class PredictResultService {
	
	/*public static void main(String[] args) {
		
		String[] columnNames= {"G2", "G1","failures","studytime","Medu"}; 
		String[] values = {"11", "10", "0", "1", "3"};
		List<String> valueList = Arrays.asList(values);
		List<List<String>> finalValueList = new ArrayList<List<String>>();
		finalValueList.add(valueList);
		Input1 input1 = new Input1();
		input1.setColumnNames(Arrays.asList(columnNames));
		input1.setValues(finalValueList);
		Inputs inputs = new Inputs();
		inputs.setInput1(input1);
		InputJson reqJson = new InputJson();
		reqJson.setInputs(inputs);
		PredictResultService servObj = new PredictResultService();
		OutputJson results = servObj.predictResult(reqJson);
		List<List<String>> predictResults = results.getResults().getOutput1().getValue().getValues();
		for (List<String> singlePredList : predictResults){			
				System.out.println("Scored Label: " + singlePredList.get(0));
				System.out.println("Standard deviation: " + singlePredList.get(1));		
			
		}
	}*/
	


	public OutputJson predictResult(InputJson requestJson){
		
		String strJson = new Gson().toJson(requestJson);
		System.out.println(strJson);

		final String uri = "https://ussouthcentral.services.azureml.net/workspaces/3526fde061f043b68a26f61b5405e501/services/565ec2e983c0452e9fec6d3b3af1a233/execute?api-version=2.0&details=true";
		final String apikey = "l2PmHWzVwzxTBXoRY996tWOJ7+hHlNmVOXp0J9qH0u/chLEXNltXhooqWcv1cNSOqRnyFpkxEZDVtVJZ/yqFlg==";
		RestTemplate restTemplate = new RestTemplate();


		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		ArrayList<MediaType> listOfMediaTypes = new ArrayList<MediaType>();
		listOfMediaTypes.add(MediaType.APPLICATION_JSON_UTF8);
		headers.setAccept(listOfMediaTypes);
		headers.set("Authorization", ("Bearer "+apikey));

		HttpEntity<InputJson> request = new HttpEntity<InputJson>(requestJson, headers);

		OutputJson finalResult = restTemplate.postForObject(uri, request, OutputJson.class);


		System.out.println(finalResult.getResults().getOutput1().getValue().getValues());
		return finalResult;
	}
	
	
	public OutputMultipleJson predictResultForMultiple(InputMultipleJson requestJson){
		
		String strJson = new Gson().toJson(requestJson);
		System.out.println(strJson);

		final String uri = "https://ussouthcentral.services.azureml.net/workspaces/3526fde061f043b68a26f61b5405e501/services/f0d96398083a4a6ea76d0bd01c1a584d/execute?api-version=2.0&details=true";
		final String apikey = "VegrzBMjAVQppP6px3ZIeIpYWs8xjcaEZJvvnQYtLy8n0yxZIRO7wLthz4DiacNbjDstRgnoMunEHj7FkaY7Ng==";
		RestTemplate restTemplate = new RestTemplate();


		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		ArrayList<MediaType> listOfMediaTypes = new ArrayList<MediaType>();
		listOfMediaTypes.add(MediaType.APPLICATION_JSON_UTF8);
		headers.setAccept(listOfMediaTypes);
		headers.set("Authorization", ("Bearer "+apikey));

		HttpEntity<InputMultipleJson> request = new HttpEntity<InputMultipleJson>(requestJson, headers);

		OutputMultipleJson finalResult = restTemplate.postForObject(uri, request, OutputMultipleJson.class);


		System.out.println(finalResult.getResults().getOutput1().getValue().getValues());
		return finalResult;
	}


}
