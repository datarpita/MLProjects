$( document ).ready(function() {

	var scoreregex = /^[0-9]+$/;

	$.validator.addMethod("validscore", function( value, element ) {
		return this.optional( element ) || scoreregex.test( value );
	});
	
	$.validator.addMethod("validscorerange", function( value, element ) {
		return this.optional( element ) || (value > 0 && value <= 20);
	});
	$("#single-form").validate({
		rules:
	    {
			grade1: {
				required: true,
				validscore: true,				
				validscorerange: true
			},
			grade2: {
				required: true,
				validscore: true,
				validscorerange: true
			},
	    },
	    messages:
	    {
	    	grade1: {
	    		required: "Please Enter score",
	    		validscore: "Score must contain only digits",
	    		validscorerange: "Score should be between 0 and 20"
	    	},
	    	grade2: {
	    		required: "Please Enter score",
	    		validscore: "Score must contain only digits",
	    		validscorerange: "Score should be between 0 and 20"
	    	},
	    },
	    errorPlacement : function(error, element) {
	        $(element).closest('.form-group').find('.help-block').html(error.html());
	    },
	    highlight : function(element) {
	        $(element).closest('.form-group').find('.help-block').addClass('alert-sm').addClass('alert-danger');
	    },
	    unhighlight: function(element, errorClass, validClass) {
	        $(element).closest('.form-group').find('.help-block').removeClass('alert-sm').removeClass('alert-danger');
	        $(element).closest('.form-group').find('.help-block').html('');
	    },
	    submitHandler: function(form) {
	    	// Prevent the form from submitting via the browser.
	    	event.preventDefault();
	    	//form.submit();
	    	ajaxPost();
	    }
	});

	function ajaxPost(){   
		var studytime = $('#studytime').val();
		var failures = $('#failures').val();
		var medu = $('#medu').val();
		var grade1 = $('#grade1').val();
		var grade2 = $('#grade2').val();
		console.log('Values--->' +studytime + '  ****** ' + failures + '*****' + medu + '******' + grade1 + '********' + grade2);
		var singlesubject =[];
		singlesubject.push({
			"studytime" : studytime,
			"failures" : failures,
			"medu" : medu,
			"grade1"  : grade1,
			"grade2"  : grade2
		});
		var inputObj = {};
		inputObj.cands=singlesubject;
		console.log('inputObj----->'+inputObj)
		$.ajax({
			url: "/singlesub",
			type: 'POST',
			dataType: 'json',
			data: JSON.stringify(inputObj),
			contentType: 'application/json',
			mimeType: 'application/json',
			success: function (data) {
				console.log(data);
				console.log("Score: " + data[0][0] + "  Standard dev: "+data[0][1]);
				$("label[for='score']").text(data[0][0]);
				$("label[for='standev']").text(data[0][1]);
				$("#resultddiv").removeClass("makeHidden").addClass("makeVisible"); 
			},
			error:function(er) {
				console.log("error: "+er);
			}
		});	

	}


	$("#resetbttn").click(function(){ 
		$("#studytime").val(-1);
		$("#failures").val(-1);
		$("#medu").val(-1);
		$("#grade1").val("");
		$("#grade2").val("");
		$("#resultddiv").removeClass("makeVisible").addClass("makeHidden"); 
	});

	$("#multiple-form").validate({
	
	
		submitHandler: function(form) {
	    	// Prevent the form from submitting via the browser.
	    	event.preventDefault();
	    	//form.submit();
	    	ajaxPost2();
	    }
	});
	
	
	function ajaxPost2(){   
		var age = $('#age').val();
		var absences = $('#absences').val();
		var famrel = $('#famrel').val();
		var goout = $('#goout').val();
		var dalc = $('#dalc').val();
		var walc = $('#walc').val();
		
		var gradem1 = $('#gradem1').val();
		var gradem2 = $('#gradem2').val();
		var gradep1 = $('#gradep1').val();
		var gradep2 = $('#gradep2').val();
		console.log('Values--->' +age + '  ****** ' + absences + '*****' + famrel + '******' + goout + '********' + dalc);
		console.log('Values--->' +walc + '  ****** ' + gradem1 + '*****' + gradem2 + '******' + gradep1 + '********' + gradep2);
		var multiplesubject =[];
		multiplesubject.push({
			"age" : age,
			"absences" : absences,
			"famrel" : famrel,
			"goout"  : goout,
			"dalc"  : dalc,
			"walc"  : walc,
			"gradem1"  : gradem1,
			"gradem2"  : gradem2,
			"gradep1"  : gradep1,
			"gradep2"  : gradep2
		});
		var inputObj = {};
		inputObj.students=multiplesubject;
		console.log('inputObj----->'+inputObj)
		$.ajax({
			url: "/multiplesub",
			type: 'POST',
			dataType: 'json',
			data: JSON.stringify(inputObj),
			contentType: 'application/json',
			mimeType: 'application/json',
			success: function (data) {
				console.log(data);
				console.log("Score1: " + data[0][0] + "  Score2: "+data[0][1]);	
				$("label[for='score_maths']").text(data[0][0]);
				$("label[for='score_physics']").text(data[0][1]);
				$('#exampleModal').modal('show');
				
				/*$("label[for='score']").text(data[0][0]);
				$("label[for='standev']").text(data[0][1]);
				$("#resultddiv").removeClass("makeHidden").addClass("makeVisible"); */
			},
			error:function(er) {
				console.log("error: "+er);
			}
		});	

	}
	
	
	
	
	
	$("#multipleNavItem").click(function(){   
		$("#tabs-1").removeClass("show").removeClass("active");
		$("#tabs-2").addClass("show").addClass("active");
		$("#singleNavItem").removeClass("active");
		$("#multipleNavItem").addClass("active");
	});

	$("#singleNavItem").click(function(){   	  
		$("#tabs-1").addClass("show").addClass("active");
		$("#tabs-2").removeClass("show").removeClass("active");
		$("#singleNavItem").addClass("active");
		$("#multipleNavItem").removeClass("active");	  
	});
});